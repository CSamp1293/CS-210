#pragma once
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
using namespace std;

class Grocer {
public:
	int grocerMenu();
	int openFile();
	int menuOption = 0;

private:
	string item;
	int frequency = 0;
	map<string, int> itemFreq;
};

int Grocer::grocerMenu() {
	do {
		cout << "~~~~~Corner Grocer~~~~~" << endl;
		cout << "1. Search for an item" << endl;
		cout << "2. Display item frequencies" << endl;
		cout << "3. Display item histogram" << endl;
		cout << "4. Exit application" << endl;
		cout << endl;
		cout << "Please enter a command: ";
		cin >> menuOption;
		cout << endl;

		switch (menuOption) {
		case 1: {
			string itemSearch;
			cout << "Please enter the item name: ";
			cin >> itemSearch;
			cout << endl;

			if (itemFreq.count(itemSearch) > 0) {
				cout << itemSearch << " " << itemFreq[itemSearch] << endl;
			}
			else {
				cout << "Item was not found." << endl;
			}
			cout << endl;
			break;
		}
		case 2: {
			for (auto&& item : itemFreq) {
				cout << item.first << " - " << item.second << endl;
			}
			cout << endl;
			break;
		}
		case 3: {
			for (auto&& item : itemFreq) {
				cout << item.first << " ";
				for (int i = 1; i <= item.second; ++i) {
					cout << "*";
				}
				cout << endl;
			}
			cout << endl;
			break;
		}
		case 4: {
			cout << "Closing application..." << endl;
			break;
		}
		default: {
			cout << "Invalid input, please enter a valid option." << endl;
		}
		}
	}
		while (menuOption != 4);
		ofstream outFS;

		outFS.open("frequency.dat");
		if (!outFS.is_open()) {
			cout << "Failed to open file frequency.dat" << endl;
			return 1;
		}

		for (auto&& item : itemFreq) {
			outFS << item.first << " - " << item.second << endl;
		}

		outFS.close();
	}

	int Grocer::openFile() {
		ifstream inputFile("CS210_Project_Three_Input_File.txt");
		if (!inputFile) {
			cout << "An error occured while attempting to open the file." << endl;
			return 1;
		}

		string line;
		string word;

		while (getline(inputFile, line)) {
			istringstream iss(line);
			while (iss >> word) {
				itemFreq[word]++;
			}
		}
	}

