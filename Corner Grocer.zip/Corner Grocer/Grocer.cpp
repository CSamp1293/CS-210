#include "Grocer.h"
#include <iostream>
using namespace std;

int main() {

	Grocer g;
	g.openFile();
	g.grocerMenu();

	return 0;
}